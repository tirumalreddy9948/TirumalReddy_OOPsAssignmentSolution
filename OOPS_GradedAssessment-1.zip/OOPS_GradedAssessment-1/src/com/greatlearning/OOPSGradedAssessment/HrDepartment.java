package com.greatlearning.OOPSGradedAssessment;

public class HrDepartment extends SuperDepartment{
	
	public String departmentName() {
		
		System.out.print("Welcome to ");
		
		return "HR Department";
	}

	
	public String getTodaysWork() {
		return "Fill today�s worksheet and mark your attendance";
	}
	
	public String getWorkDeadline() {
		return "Complete by EOD";
	}
	
	
	public String doActivity() {
		return "team Lunch";
	}

}
